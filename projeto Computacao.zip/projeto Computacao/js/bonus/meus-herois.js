// ============================================================
//  🦸 BÔNUS — CRIE OS SEUS PRÓPRIOS HERÓIS
//
//  Só mexam aqui DEPOIS de terminar os 11 TODOs e jogar uma partida!
//
//  Cada herói é um objeto, igual ao `produto` da Semana 4.
//  Para criar um herói novo:
//    1. Copie o modelo abaixo (tirando os // do começo de cada linha).
//    2. Troque os valores pelos do seu herói.
//    3. Salve (Ctrl + S) e recarregue a página (F5).
//
//  REGRAS (a página avisa em amarelo se alguma for quebrada):
//    • Os heróis novos precisam vir em número PAR (2, 4, 6...),
//      para os dois jogadores receberem a mesma quantidade de cartas.
//    • forca, velocidade, inteligencia e poder: números de 0 a 100,
//      escritos SEM acento e SEM aspas.
//    • Coloquem uma vírgula depois de cada herói e de cada propriedade.
//
//  EQUIPE: pode ser uma das 4 que já existem
//    'Guardiões do Sol', 'Liga da Maré', 'Sentinelas da Noite',
//    'Tropa Relâmpago'
//  ou uma NOVA (ela aparece sozinha na coleção). Para escolher a cor
//  de uma equipe nova, acrescente  cor: '#ff0066'  no primeiro herói dela.
//
//  IMAGEM (opcional): coloque o arquivo na pasta `imagens/` e escreva
//  o caminho:  imagem: 'imagens/meu-heroi.png'
//  Também funciona com o endereço de uma imagem da internet:
//     imagem: 'https://site.com/foto.jpg'
//  Se a imagem não carregar, a carta mostra o emoji no lugar.
//
//  DICA DE BALANCEAMENTO: a força total é a soma dos 4 atributos.
//  Os heróis do jogo ficam entre 230 e 320. Um herói com 90 em tudo
//  ganha sempre — e jogo em que alguém ganha sempre perde a graça! 😉
// ============================================================

const MEUS_HEROIS = [

  // ----- MODELO (copie, tire os // e mude os valores) -----
  // {
  //   nome: 'Capitão Pixel',
  //   equipe: 'Tropa Relâmpago',
  //   emoji: '🎮',
  //   imagem: 'imagens/exemplo-heroi.svg',
  //   forca: 60,
  //   velocidade: 85,
  //   inteligencia: 90,
  //   poder: 55,
  // },

  {
    nome: 'Parafernalia',
    equipe: 'Swat',
    emoji: '🦸‍♀️',
    imagem: 'imagens/parafernalia.png',
    forca: 70,
    velocidade: 80,
    inteligencia: 90,
    poder: 60,
  },



  {
    nome: 'Negrinho do Pastoreio',
    equipe: 'sixseven',
    emoji: '🦸‍♀️',
    imagem: 'imagens/negrinho.png',
    forca: 67,
    velocidade: 67,
    inteligencia: 76,
    poder: 97,
  },

{
    nome: 'Lebron James',
    equipe: 'The Goat',
    emoji: '👩🏿‍🦲',
    imagem: 'imagens/lebron.png',
    forca: 99,
    velocidade: 80,
    inteligencia: 96,
    poder: 99,
  },


  {
    nome: 'Toxapex',
    equipe: 'Alola',
    emoji: '💔',
    imagem: 'imagens/toxapex.png',
    forca: 45,
    velocidade: 23,
    inteligencia: 99,
    poder: 67,
  },
  
  {
    nome: 'Goku',
    equipe: 'Drip',
    emoji: '👱🏼‍♂️',
    imagem: 'imagens/goku.png',
    forca: 100,
    velocidade: 80,
    inteligencia: 96,
    poder: 99,
  },

 {
    nome: 'Obsidian',
    equipe: 'Pedras',
    emoji: '⬛',
    imagem: 'imagens/obsidian.png',
    forca: 99,
    velocidade: 1,
    inteligencia: 1,
    poder: 99,
  },


];
